# vd-repo
This repo contains my terrible plugins & themes.

# How to install?
Plugins:
Go to https://sdh.gay/vendetta and copy the plugin link and paste it into Vendetta.
If this does not work paste the link below into Vendetta and replace `PLUGIN_NAME` with the plugin you want to install.

`https://vendetta.sdh.gay/PLUGIN_NAME`

Themes:
Go to https://sdh.gay/vendetta and copy the theme link and paste it into Vendetta.
If this does not work paste the link below into Vendetta and replace `THEME_NAME` with the theme you want to install.

`https://vendetta.sdh.gay/THEME_NAME.json`
